import java.util.ArrayList;
import java.util.Random;

public class randomInteger {

    
    public static boolean isPrime(int num) {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;

        for (int i = 3; i <= Math.sqrt(num); i += 2) {
            if (num % i == 0) return false;
        }
        return true;
    }


    public static int generateRandomPrime(int min, int max) {
        ArrayList<Integer> primeList = new ArrayList<>();

        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                primeList.add(i);
            }
        }

        if (primeList.isEmpty()) {
            throw new IllegalArgumentException("No prime numbers found in the given range.");
        }

        Random rand = new Random();
        int randomIndex = rand.nextInt(primeList.size());
        return primeList.get(randomIndex);
    }

    public static void main(String[] args) {
        int min = 10;
        int max = 20;

        try {
            int randomPrime = generateRandomPrime(min, max);
            System.out.println("Random prime between " + min + " and " + max + ": " + randomPrime);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
