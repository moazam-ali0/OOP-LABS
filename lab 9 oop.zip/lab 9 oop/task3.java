abstract class shape {
    abstract double area();
}

interface printtable {
    void print();
}

class rectangle extends shape implements printtable {
    private double width;
    private double height;

    rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double area() {
        return width * height;
    }

    public void print() {
        System.out.println("Printing area of rectangle: " + area());
    }
}

public class task3 {
    public static void main(String[] args) {
        rectangle r1 = new rectangle(130, 79); 
        r1.print();
    }
}
