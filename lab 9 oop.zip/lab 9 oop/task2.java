interface vehicle {
    void start();
    void stop();
}

class car implements vehicle {
    public void start() {
        System.out.println("car is starting");
    }

    public void stop() {
        System.out.println("car is stopping");
    }
}

class bike implements vehicle {
    public void start() {
        System.out.println("bike is starting");
    }

    public void stop() {
        System.out.println("bike is stopping");
    }
}

public class task2 {
    public static void main(String[] args) {
        car c1 = new car();
        bike b1 = new bike();

        c1.start();
        b1.start();
        c1.stop();
        b1.stop();
    }
}
