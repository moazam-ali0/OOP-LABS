import java.util.ArrayList;
import java.util.Random;

public class randomPrimenumber {


    public static boolean isPrime(int num) {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;

        for (int i = 3; i <= Math.sqrt(num); i += 2) {
            if (num % i == 0) return false;
        }

        return true;
    }


    public static int generateRandomPrime(int min, int max) {
        ArrayList<Integer> primes = new ArrayList<>();

        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                primes.add(i);
            }
        }

        if (primes.isEmpty()) {
            throw new IllegalArgumentException("No prime numbers found in the given range.");
        }

        Random random = new Random();
        int randomIndex = random.nextInt(primes.size());
        return primes.get(randomIndex);
    }

    public static void main(String[] args) {
        int min = 10;
        int max = 50;

        try {
            int prime = generateRandomPrime(min, max);
            System.out.println("Random prime between " + min + " and " + max + ": " + prime);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}
