abstract class animal {
    abstract void makesound();

    void eat() {
        System.out.println("animal is eating");
    }
}

class dog extends animal {
    void makesound() {
        System.out.println("dog is barking");
    }
}

class cat extends animal {
    void makesound() {
        System.out.println("cat makes sound");
    }
}

class task1 {
    public static void main(String[] args) {
        dog d1 = new dog();
        cat c1 = new cat();

        d1.eat();
        c1.eat();
        d1.makesound();
        c1.makesound();
    }
}
