import java.util.HashSet;

public class LongestSubstring {

    
    public static int longestUniqueSubstring(String str) {
        int maxLength = 0;
        int left = 0;
        HashSet<Character> seen = new HashSet<>();

        for (int right = 0; right < str.length(); right++) {
            char current = str.charAt(right);

            
            while (seen.contains(current)) {
                seen.remove(str.charAt(left));
                left++;
            }

            seen.add(current);
            maxLength = Math.max(maxLength, right - left + 1);
        }

        return maxLength;
    }

    public static void main(String[] args) {
        String input = "abcabcbb";
        int result = longestUniqueSubstring(input);
        System.out.println("Length of longest unique substring: " + result);
    }
}
