public interface Flyable{
public void fly();

}
public interface  Swimmable{
public void swim();


}
public class Duck implements Flyable,Swimmable {
public void fly(){
System.out.println("Duck is Little Flying");}
public void swim(){
System.out.println("Duck is Swimming");}


}
public class Task_4{
public static void main(String []args){
Duck d1= new Duck();
d1.fly();
d1.swim();
}
}