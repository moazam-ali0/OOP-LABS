
public abstract class Employee{
String name, id;
public abstract double calculateSalary();


}

public interface TaxPayer{
public double payTax();




}

public class FullTimeEmployee extends Employee implements TaxPayer
{

public double calculateSalary(){
final double salary= 100000;
return salary;}
public double payTax(){
final int Tax_per_month=1000;
double salary =calculateSalary();
return salary-Tax_per_month;
}
} 

public class PartTimeEmployee extends Employee implements TaxPayer{
public int hours=10;

public double calculateSalary(){
final double salary_per_hours=1000;
return hours*salary_per_hours; }
public double payTax(){
final int Tax_per_month=1000;
double salary= calculateSalary();
return salary-Tax_per_month;

}


}

public class Task_5{
public static void main(String []args){
FullTimeEmployee f1= new FullTimeEmployee();
PartTimeEmployee p1 =new PartTimeEmployee();
System.out.println("The salary of full Timed employee :"+f1.calculateSalary());
System.out.println("TAX PAID (IN MONTH):"+f1.payTax());
System.out.println("The salary of Part Timed employee for 10 hours :"+p1.calculateSalary());
System.out.println("TAX PAID (IN MONTH):"+p1.payTax());


}}
